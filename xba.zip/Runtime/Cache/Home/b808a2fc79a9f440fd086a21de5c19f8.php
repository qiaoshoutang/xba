<?php if (!defined('THINK_PATH')) exit();?>
<!--底部黑色-->
<div class="bottom-box">
    <div class="bottom-text">
        <div class="bottom-text-left">
            <div class="Tt-bottom">友情链接</div>
            <p style="margin-top: 20px"><a href="">厦门大学区块链研究中心</a><a href="">厦门蚂蚁节点联盟区块链有限公司</a><a href="">厦门安妮股份有限公司</a></p>
            <p><a href="">厦门蚂蚁节点联盟区块链有限公司</a><a href="">厦门大学区块链研究中心</a><a href="">厦门大学区块链研究中心</a></p>
            <p><a href="">厦门大学区块链研究中心</a><a href="">厦门蚂蚁节点联盟区块链有限公司</a><a href="">厦门大学区块链研究中心</a></p>
            <p><a href="">厦门安妮股份有限公司</a><a href="">厦门大学区块链研究中心</a><a href="">厦门安妮股份有限公司</a></p>
        </div>

        <div class="bottom-text-right">
            <div class="Tt-bottom">联系我们</div>
            <p style="margin-top: 20px">0592-666666</p>
            <p>xiamenqukuailian@xba.org</p>
            <p>厦门大学区块链研究中心</p>
        </div>

    </div>

</div>