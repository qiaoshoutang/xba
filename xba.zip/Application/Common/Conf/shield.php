<?php
return array(
    /* 安全设置 */
    'LOG_RECORD'=>true, // 日志记录
    'SHOW_ERROR_MSG'=>true, // 出错显示
    'DB_SQL_LOG'=>false, // SQL日志
    'COOKIE_PREFIX'=>'it6sJ_', // COOKIE前缀
    'SAFE_KEY'=>'WBCoUwNTw2j8l8W0EC4n', // 加密码
);