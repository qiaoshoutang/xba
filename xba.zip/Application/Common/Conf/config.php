<?php
return array(
	//'配置项'=>'配置值'
    'TMPL_TEMPLATE_SUFFIX'=>'.html',
    'LOAD_EXT_CONFIG' => 'performance,shield,db',
    'VAR_SESSION_ID' => 'session_id',
	'SITE_URL' => '',
	);