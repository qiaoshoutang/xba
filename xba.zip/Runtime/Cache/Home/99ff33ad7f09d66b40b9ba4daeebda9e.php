<?php if (!defined('THINK_PATH')) exit();?>
<!--顶部导航栏-->
<div class="nav-header-box">
    <div class="nav-header-logo">
        <img src="images/logo.png" alt="">
    </div>
    <div class="nav-header">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="">关于协会</a></li>
            <li><a href="/xbadynamic/1">协会动态</a></li>
            <li><a href="">协会活动</a></li>
            <li><a href="">协会会员</a></li>
            <li><a href="">行业研究</a></li>
            <li><a href="">会员申请</a></li>
        </ul>
    </div>
</div>