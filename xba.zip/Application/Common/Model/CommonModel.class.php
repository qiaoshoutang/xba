<?php
namespace Common\Model;
use Think\Model;

class CommonModel extends Model {
	
	public function __construct() {
		
		
	}

	
	
}

?>