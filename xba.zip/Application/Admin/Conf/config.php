<?php
return array(
	//'配置项'=>'配置值'
	'APP_STATE'=> true,
	'APP_INSTALL'=> true,
);