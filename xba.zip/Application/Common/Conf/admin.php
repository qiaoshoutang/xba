<?php
 return array (
  'TMPL_CACHE_ON' => true,
  'HTML_CACHE_ON' => false,
  'DB_SQL_BUILD_CACHE' => false,
  'URL_MODEL' => 3,
  'URL_ROUTER_ON' => false,
  'LOG_RECORD' => true, // 日志记录
  'SHOW_ERROR_MSG' => true, // 出错显示
  'DB_SQL_LOG' => false, // SQL日志
  'TAGLIB_PRE_LOAD'    =>    'admin',
);